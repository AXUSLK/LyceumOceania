    <!-- jQuery Scripts -->
    <script src="js/jquery.min.js"></script>
    <script src="js/scripts.min.js"></script>

    <!-- Revolution Slider Addons -->

    <!-- DISTORTION ADD-ON FILES -->
    <link rel='stylesheet' href='revolution-addons/distortion/css/distortion.css' type='text/css' media='all' />
    <script type='text/javascript' src='revolution-addons/distortion/js/pixi.min.js'></script>
    <script type='text/javascript' src='revolution-addons/distortion/js/revolution.addon.distortion.min.js'></script>


    <script type="text/javascript" src="revolution/js/extensions/revolution.extension.video.min.js"></script>
    <script type="text/javascript" src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
    <script type="text/javascript" src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
    <script type="text/javascript" src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
    <script type="text/javascript" src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
    <script type="text/javascript" src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
    <script type="text/javascript" src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
    <script type="text/javascript" src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
    <script type="text/javascript" src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
