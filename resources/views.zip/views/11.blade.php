<video autoplay muted loop width="1920" height="1080" controls id="myVideso">
    <source src="lyceum_oceiana_cover.mp4" type="video/mp4">
</video>
